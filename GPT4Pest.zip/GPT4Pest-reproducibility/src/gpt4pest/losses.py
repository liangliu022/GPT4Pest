import torch
import torch.nn.functional as F

def image_to_text_infonce(image_embeddings, text_embeddings, temperature):
    """
    One-way image-to-text InfoNCE matching the manuscript's Eq. (8):
    diagonal image/text pairs are positives; other in-batch texts are negatives.
    """
    if temperature is None or temperature <= 0:
        raise ValueError("temperature (tau) must be set to a positive value")
    logits = image_embeddings @ text_embeddings.T
    logits = logits / temperature
    targets = torch.arange(logits.size(0), device=logits.device)
    return F.cross_entropy(logits, targets)

def combined_loss(class_logits, labels, image_embeddings, text_embeddings,
                  temperature, alignment_weight):
    if alignment_weight is None:
        raise ValueError("alignment_weight (lambda) must be set")
    cls = F.cross_entropy(class_logits, labels)
    align = image_to_text_infonce(image_embeddings, text_embeddings, temperature)
    total = cls + float(alignment_weight) * align
    return total, {"classification": cls.detach(), "alignment": align.detach()}
