import torch
import torch.nn as nn
import torch.nn.functional as F
import timm

class GPT4PestModel(nn.Module):
    """
    ResMLP-based visual classifier plus image/text projection heads.

    IMPORTANT: set `visual_model_name` to the exact ResMLP variant used in the
    original experiment. The manuscript does not identify that variant. The
    implementation uses timm's num_classes=0 feature interface; if the original
    ResMLP implementation differs, replace this adapter with the original code.
    """
    def __init__(self, visual_model_name, num_classes, text_dim,
                 projection_dim, pretrained=False, projection_hidden_dim=None):
        super().__init__()
        if not visual_model_name or visual_model_name.startswith("TODO"):
            raise ValueError("Set the exact ResMLP model name in configs/default.yaml")
        self.visual_encoder = timm.create_model(
            visual_model_name, pretrained=pretrained, num_classes=0
        )
        visual_dim = getattr(self.visual_encoder, "num_features", None)
        if visual_dim is None:
            raise ValueError("Could not infer visual feature dimension; adapt model wrapper.")
        self.classifier = nn.Linear(visual_dim, num_classes)

        hidden = projection_hidden_dim or visual_dim
        self.visual_projection = nn.Sequential(
            nn.Linear(visual_dim, hidden),
            nn.GELU(),
            nn.Linear(hidden, projection_dim),
        )
        self.text_projection = nn.Sequential(
            nn.Linear(text_dim, hidden),
            nn.GELU(),
            nn.Linear(hidden, projection_dim),
        )

    def forward(self, images, text_embeddings=None):
        visual_features = self.visual_encoder(images)
        logits = self.classifier(visual_features)
        output = {"logits": logits, "visual_features": visual_features}
        if text_embeddings is not None:
            zv = F.normalize(self.visual_projection(visual_features), dim=-1)
            zt = F.normalize(self.text_projection(text_embeddings), dim=-1)
            output.update({"image_embedding": zv, "text_embedding": zt})
        return output

    @torch.no_grad()
    def predict(self, images):
        return self.forward(images)["logits"]
