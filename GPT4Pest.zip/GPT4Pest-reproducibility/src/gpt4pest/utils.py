import os
import random
import numpy as np
import torch
import yaml

def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

def load_config(path):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def resolve_path(root, path):
    if os.path.isabs(path):
        return path
    return os.path.normpath(os.path.join(root, path))
