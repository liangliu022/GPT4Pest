from pathlib import Path
import pandas as pd
from PIL import Image
import torch
from torch.utils.data import Dataset
from torchvision import transforms

class PestImageDataset(Dataset):
    def __init__(self, csv_path, image_root=".", image_size=224,
                 text_embeddings=None, train=False):
        self.df = pd.read_csv(csv_path)
        self.image_root = Path(image_root)
        self.text_embeddings = text_embeddings
        self.train = train
        ops = [
            transforms.Resize((image_size, image_size)),
        ]
        if train:
            # Conservative standard image augmentation scaffold.
            # Replace with the exact manuscript implementation/logged parameters.
            ops += [
                transforms.RandomHorizontalFlip(),
                transforms.RandomRotation(10),
            ]
        ops += [
            transforms.ToTensor(),
            transforms.Normalize(mean=(0.485, 0.456, 0.406),
                                 std=(0.229, 0.224, 0.225)),
        ]
        self.transform = transforms.Compose(ops)

        labels = sorted(self.df["label"].astype(str).unique().tolist())
        self.label_to_index = {name: i for i, name in enumerate(labels)}
        self.df["label_index"] = self.df["label"].astype(str).map(self.label_to_index)

        if text_embeddings is not None:
            self.embeddings = torch.load(text_embeddings, map_location="cpu")
        else:
            self.embeddings = None

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        image_path = Path(row["image_path"])
        if not image_path.is_absolute():
            image_path = self.image_root / image_path
        image = Image.open(image_path).convert("RGB")
        image = self.transform(image)
        item = {
            "image": image,
            "label": torch.tensor(int(row["label_index"]), dtype=torch.long),
            "image_id": str(row["image_id"]),
        }
        if self.embeddings is not None:
            key = str(row["image_id"])
            if key not in self.embeddings:
                raise KeyError(f"No cached text embedding for image_id={key}")
            item["text_embedding"] = self.embeddings[key].float()
        return item
