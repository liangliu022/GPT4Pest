import torch
from sklearn.metrics import accuracy_score, precision_recall_fscore_support

def run_epoch(model, loader, device, optimizer=None, temperature=None,
              alignment_weight=None):
    training = optimizer is not None
    model.train(training)
    total_loss = 0.0
    y_true, y_pred = [], []

    for batch in loader:
        images = batch["image"].to(device)
        labels = batch["label"].to(device)
        texts = batch.get("text_embedding")
        if texts is not None:
            texts = texts.to(device)

        with torch.set_grad_enabled(training):
            if training:
                if texts is None:
                    raise RuntimeError("Training requires cached text embeddings.")
                from .losses import combined_loss
                out = model(images, texts)
                loss, _ = combined_loss(
                    out["logits"], labels, out["image_embedding"],
                    out["text_embedding"], temperature, alignment_weight
                )
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                optimizer.step()
            else:
                out = model(images)
                loss = torch.nn.functional.cross_entropy(out["logits"], labels)

        total_loss += float(loss.detach().cpu()) * labels.size(0)
        preds = out["logits"].argmax(dim=1)
        y_true.extend(labels.cpu().tolist())
        y_pred.extend(preds.cpu().tolist())

    precision, recall, f1, _ = precision_recall_fscore_support(
        y_true, y_pred, average="macro", zero_division=0
    )
    return {
        "loss": total_loss / max(1, len(y_true)),
        "accuracy": accuracy_score(y_true, y_pred),
        "macro_precision": precision,
        "macro_recall": recall,
        "macro_f1": f1,
    }
