# CPest data organization

The manuscript reports 4,510 curated original images from 40 pest categories and 22,550 image files after augmentation. The original images were split 8:1:1 at source-image level before augmentation; augmentation was applied only to the training partition. The validation and test partitions retained original images.

## Required metadata

Copy `metadata/images_template.csv` to `metadata/images.csv` and fill it with actual records. Do not fabricate source URLs or IDs.

| Column | Meaning |
|---|---|
| image_id | Unique ID for this file |
| image_path | Relative or absolute local path |
| label | Exact category name |
| source_id | Stable ID of the original source image |
| source_url | Original source URL, if known |
| split | train / val / test; assigned by split script |
| is_augmented | true / false |
| parent_image_id | Original image ID for derivative files |

For original files, `source_id` should be unique per original source image. For every augmented or synthetic derivative, retain the same `source_id` as its parent so that all derivatives remain in the same split.

## Copyright and traceability

Do not upload third-party image files unless redistribution is permitted. Where possible, publish source URLs, retrieval dates, category labels, source identifiers, and access/license notes. A URL list alone may not guarantee that images remain available. Document unavailable or inaccessible sources honestly.

## Augmentation

The manuscript names affine transformations, random cropping, rotation, scaling, horizontal flipping, and diffusion-model-based image enhancement. Exact implementation details are not supplied in the manuscript. Record the actual transform probabilities/ranges and the diffusion model/checkpoint, prompts, conditioning, sampling parameters, number of generated images, screening procedure, and morphological preservation criteria in `docs/DATA_CARD.md`.

Synthetic and transformed files are derivatives, not independent biological observations.
