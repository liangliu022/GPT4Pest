# Reproducibility checklist before public release

## Dataset
- [ ] Verify 4,510 original images and 40 categories from the actual manifest.
- [ ] Reconcile the reported 22,550 files with the split counts and augmentation logs.
- [ ] Publish legally shareable source records and retrieval metadata.
- [ ] Confirm labels and duplicate handling.
- [ ] Confirm source-image-level split and no derivative leakage.
- [ ] Publish actual split seed/manifests.

## Augmentation
- [ ] Record transform libraries, versions, probabilities, and ranges.
- [ ] Record diffusion model/checkpoint/version and all generation settings.
- [ ] Record generated image count and screening/quality-control criteria.
- [ ] State that synthetic derivatives are not independent biological observations.

## Models
- [ ] Exact ResMLP architecture/model identifier and source code.
- [ ] Exact image size, patch size, normalization, and preprocessing.
- [ ] Exact BERT checkpoint/revision and tokenizer.
- [ ] Text pooling strategy and max token length.
- [ ] Whether BERT is frozen or fine-tuned.
- [ ] Projection head architecture and dimensions.
- [ ] Classifier head architecture.

## Optimization
- [ ] Exact `tau` and `lambda_align`.
- [ ] SGD momentum, weight decay, scheduler, warm-up, and gradient clipping.
- [ ] Batch size and treatment of incomplete batches.
- [ ] Random seeds and deterministic settings.
- [ ] Number of independent runs and definition of reported mean ± SD.
- [ ] Checkpoint selection criterion and validation protocol.

## Description generation
- [ ] MiniGPT-4 checkpoint/version and code commit.
- [ ] Exact prompt template and any system prompt.
- [ ] Decoding parameters and image preprocessing.
- [ ] Description generation performed for training images only.
- [ ] Save generated text and provenance metadata.

## Evaluation and reporting
- [ ] Confirm test set was not used for model selection.
- [ ] Publish per-class precision/recall/F1 and confusion matrix.
- [ ] Document AUC calculation for multiclass classification.
- [ ] Clarify whether parameter/FLOP counts include text branch and projection heads.
- [ ] Separate training-time cost from visual-only inference cost.
- [ ] Verify all table values against saved logs.

## Repository and manuscript
- [ ] Replace every TODO placeholder.
- [ ] Run scripts from a clean environment.
- [ ] Add exact dependency lock/export.
- [ ] Add repository URL to manuscript only after public access is verified.
- [ ] Make Data Availability wording match the actual released files.
- [ ] Add a release tag and archived DOI if possible.
