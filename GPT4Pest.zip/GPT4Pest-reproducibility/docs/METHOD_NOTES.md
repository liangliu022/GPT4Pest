# Method implementation notes

## Training-time data flow
For a training image `x_i` with known training label `y_i`, the manuscript defines a class-conditioned description:

`t_i = G(x_i, p(y_i))`

where `G` is the MLLM (reported as MiniGPT-4) and the prompt is reported as:

`Describe the [pestname] in this image in detail.`

The generated description is encoded by BERT. The manuscript reports precomputing and caching text embeddings before visual-model training.

## Visual branch
The manuscript defines:
- `h_v = F_theta(x)` visual feature;
- `s = C_psi(h_v)` class logits for 40 categories;
- softmax probabilities over the 40 classes.

The exact ResMLP variant and feature extraction interface are not specified in the manuscript. Set the exact `timm` model name or replace the adapter in `src/gpt4pest/models.py` with the original implementation.

## Shared embedding space
The visual and text features are projected and L2-normalized:
- `z_v = normalize(P_v(h_v))`
- `z_t = normalize(P_t(h_t))`

The projection dimensions and detailed projection-head architecture must be recovered from the original code.

## Objectives
Classification cross entropy:

`L_cls = mean_i CrossEntropy(s_i, y_i)`

Image-to-text InfoNCE as described in the manuscript:

`L_align = -mean_i log [ exp(sim(zv_i, zt_i)/tau) / sum_j exp(sim(zv_i, zt_j)/tau) ]`

Combined objective:

`L = L_cls + lambda * L_align`

The paper describes other descriptions in the mini-batch as negative candidates. This implementation uses that one-way image-to-text formulation. If the original code uses a symmetric loss, a mask for same-class examples, or another denominator, update the implementation and paper together.

## Inference
Only the visual encoder and classification head are needed. Text generation and text encoding are not called for each test image.
