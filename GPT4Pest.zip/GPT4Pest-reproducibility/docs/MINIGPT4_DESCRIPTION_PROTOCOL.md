# MiniGPT-4 description generation protocol

The manuscript reports the following prompt:

`Describe the [pestname] in this image in detail.`

The generation implementation must be linked to the actual MiniGPT-4 checkpoint and code version used by the authors. This repository does not include an unverified wrapper because MiniGPT-4 deployments differ in checkpoint loading, conversation templates, image preprocessing, and inference arguments.

For each training image, save:
- `image_id`
- exact class label inserted into the prompt
- exact prompt text and any system instruction
- generated description (verbatim)
- model repository/checkpoint and revision
- decoding parameters (temperature, top-p, beam settings, max tokens)
- image resize/crop procedure
- generation date and software environment

Generate descriptions for training images only. If validation/test descriptions were generated for qualitative illustration, keep them out of the training embedding cache and disclose their purpose separately.

The category-conditioned prompt uses the known training label. This is auxiliary training supervision; it is not independent expert-verified biological knowledge.
