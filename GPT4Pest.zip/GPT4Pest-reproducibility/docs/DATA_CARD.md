# CPest data card

## Dataset identity
- Name: CPest
- Task: fine-grained agricultural pest image classification
- Categories: 40
- Original curated source images reported: 4,510
- Total files reported after augmentation: 22,550

## Source and collection
The manuscript states that images were collected from specialist agricultural pest image/video websites and general search engines using Chinese and English search terms. Target crop groups include maize, soybean, wheat, and rapeseed. The initial collection was approximately 6,000 images; manual screening removed blurred/excessively noisy images and images without a visible target pest.

**To complete before release:** list all source websites, URLs or stable identifiers, retrieval dates, search terms, licenses/access conditions, and the actual screening rules. Do not claim that these details are available unless they are present in the authors' records.

## Labels
Document the 40 exact category names, taxonomic authority/synonyms, annotation process, annotator expertise, disagreement resolution, and any expert verification. The manuscript does not fully describe these items.

## Partitioning
The manuscript reports an 8:1:1 source-image-level split before augmentation. Publish the actual split manifest or a deterministic script and seed. Check that duplicate images and augmented derivatives cannot cross partitions.

## Augmentation
Reported operations: affine transformations, random cropping, rotation, scaling, horizontal flipping, and diffusion-model-based image enhancement.

**Required details:** library and version; transform parameters and probabilities; diffusion model name/version/checkpoint; prompt and conditioning; sampling settings; number of synthetic outputs; filtering/manual review; rules for preserving diagnostic morphology.

## Known limitations
- Online-collected images are not a probability sample of field observations.
- Source availability and copyright may restrict redistribution.
- Transformations and synthetic generation may alter diagnostic morphology.
- The dataset does not establish performance across independent farms, seasons, regions, or acquisition devices.
- Synthetic derivatives do not increase the number of independent biological observations.
