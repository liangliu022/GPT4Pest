import argparse
from pathlib import Path
import torch
from torch.utils.data import DataLoader
from gpt4pest.utils import load_config, set_seed
from gpt4pest.data import PestImageDataset
from gpt4pest.models import GPT4PestModel
from gpt4pest.engine import run_epoch

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True)
    args = p.parse_args()
    cfg = load_config(args.config)
    set_seed(int(cfg["seed"]))
    device = "cuda" if torch.cuda.is_available() else "cpu"

    m = cfg["model"]
    if m["projection_dim"] is None or cfg["loss"]["temperature"] is None or cfg["loss"]["alignment_weight"] is None:
        raise ValueError("Complete TODO fields: projection_dim, temperature, alignment_weight.")
    train_ds = PestImageDataset(cfg["data"]["train_csv"], cfg["data"]["image_root"],
        cfg["image_size"] if "image_size" in cfg else 224,
        cfg["data"]["text_embeddings"], train=True)
    val_ds = PestImageDataset(cfg["data"]["val_csv"], cfg["data"]["image_root"],
        cfg["image_size"] if "image_size" in cfg else 224, train=False)
    train_loader = DataLoader(train_ds, batch_size=cfg["batch_size"], shuffle=True,
                              num_workers=cfg["num_workers"], drop_last=True)
    val_loader = DataLoader(val_ds, batch_size=cfg["batch_size"], shuffle=False,
                            num_workers=cfg["num_workers"])

    model = GPT4PestModel(
        m["visual_model_name"], cfg["num_classes"],
        text_dim=next(iter(train_ds.embeddings.values())).numel(),
        projection_dim=m["projection_dim"], pretrained=m["pretrained"],
        projection_hidden_dim=m["projection_hidden_dim"]
    ).to(device)

    # The manuscript reports SGD and lr=1e-4; momentum/weight decay remain TODO.
    optimizer = torch.optim.SGD(
        model.parameters(), lr=cfg["learning_rate"],
        momentum=cfg["momentum"] or 0.0,
        weight_decay=cfg["weight_decay"] or 0.0
    )
    out_dir = Path(cfg["training"]["output_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    best = -1.0
    for epoch in range(cfg["epochs"]):
        tr = run_epoch(model, train_loader, device, optimizer,
                       cfg["loss"]["temperature"], cfg["loss"]["alignment_weight"])
        va = run_epoch(model, val_loader, device)
        print(f"epoch={epoch+1} train={tr} val={va}")
        if va["macro_f1"] > best:
            best = va["macro_f1"]
            torch.save({"model": model.state_dict(), "epoch": epoch+1,
                        "val_metrics": va, "config": cfg}, out_dir / "best.pt")

if __name__ == "__main__":
    main()
