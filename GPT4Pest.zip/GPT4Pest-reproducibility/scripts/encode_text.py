import argparse
import pandas as pd
import torch
from transformers import AutoTokenizer, AutoModel
from tqdm import tqdm

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--descriptions", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--model-name", required=True)
    p.add_argument("--max-length", type=int, default=128)
    p.add_argument("--batch-size", type=int, default=16)
    args = p.parse_args()

    df = pd.read_csv(args.descriptions).dropna(subset=["image_id", "description"])
    device = "cuda" if torch.cuda.is_available() else "cpu"
    tokenizer = AutoTokenizer.from_pretrained(args.model_name)
    model = AutoModel.from_pretrained(args.model_name).to(device).eval()
    cache = {}
    with torch.no_grad():
        for start in tqdm(range(0, len(df), args.batch_size)):
            part = df.iloc[start:start + args.batch_size]
            texts = part["description"].astype(str).tolist()
            toks = tokenizer(texts, padding=True, truncation=True,
                             max_length=args.max_length, return_tensors="pt").to(device)
            out = model(**toks).last_hidden_state
            mask = toks["attention_mask"].unsqueeze(-1)
            # Mean pooling; verify against the original implementation.
            pooled = (out * mask).sum(1) / mask.sum(1).clamp(min=1)
            for image_id, emb in zip(part["image_id"].astype(str), pooled.cpu()):
                cache[image_id] = emb.float()
    torch.save(cache, args.output)
    print(f"Saved {len(cache)} embeddings to {args.output}")

if __name__ == "__main__":
    main()
