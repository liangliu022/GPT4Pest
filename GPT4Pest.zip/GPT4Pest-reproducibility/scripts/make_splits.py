import argparse
from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args()

    df = pd.read_csv(args.input)
    required = {"image_id", "image_path", "label", "source_id", "is_augmented"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")
    originals = df[df["is_augmented"].astype(str).str.lower().isin(["false","0","no"])].copy()
    if originals.empty:
        raise ValueError("No original images found (is_augmented=false).")
    if originals["source_id"].duplicated().any():
        raise ValueError("Original source_id should be unique in this source-level manifest.")

    source = originals[["source_id", "label"]].copy()
    train_ids, hold_ids = train_test_split(
        source["source_id"], test_size=0.2, random_state=args.seed,
        stratify=source["label"]
    )
    hold = source[source["source_id"].isin(hold_ids)]
    val_ids, test_ids = train_test_split(
        hold["source_id"], test_size=0.5, random_state=args.seed,
        stratify=hold["label"]
    )
    mapping = {sid: "train" for sid in train_ids}
    mapping.update({sid: "val" for sid in val_ids})
    mapping.update({sid: "test" for sid in test_ids})

    # Derivatives inherit the split of their original source_id.
    df["split"] = df["source_id"].map(mapping)
    if df["split"].isna().any():
        bad = df.loc[df["split"].isna(), "source_id"].dropna().unique()[:5]
        raise ValueError(f"Some records have source_id not found among originals: {bad}")

    # Augmented files are only allowed in training.
    aug = df["is_augmented"].astype(str).str.lower().isin(["true","1","yes"])
    if (df.loc[aug, "split"] != "train").any():
        raise RuntimeError("Augmented derivatives crossed into validation/test.")
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    for split in ["train", "val", "test"]:
        part = df[df["split"] == split].copy()
        part.to_csv(out / f"{split}.csv", index=False)
        print(f"{split}: {len(part)} files; {part['source_id'].nunique()} source images")
    df.to_csv(out / "all_with_splits.csv", index=False)

if __name__ == "__main__":
    main()
