import argparse
import torch
from torch.utils.data import DataLoader
from gpt4pest.utils import load_config
from gpt4pest.data import PestImageDataset
from gpt4pest.models import GPT4PestModel
from gpt4pest.engine import run_epoch

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True)
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--split", required=True)
    args = p.parse_args()
    cfg = load_config(args.config)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    ds = PestImageDataset(args.split, cfg["data"]["image_root"],
                          cfg.get("image_size", 224), train=False)
    loader = DataLoader(ds, batch_size=cfg["batch_size"], shuffle=False,
                        num_workers=cfg["num_workers"])
    ckpt = torch.load(args.checkpoint, map_location=device)
    m = cfg["model"]
    # Text dimension is not needed for visual-only evaluation; instantiate using
    # a harmless configured placeholder and load only after exact dimensions are set.
    if m["projection_dim"] is None:
        raise ValueError("Set projection_dim to instantiate the trained architecture.")
    model = GPT4PestModel(m["visual_model_name"], cfg["num_classes"],
        text_dim=ckpt["config"]["model"].get("text_dim", m.get("text_dim", 768)),
        projection_dim=m["projection_dim"], pretrained=False,
        projection_hidden_dim=m["projection_hidden_dim"]).to(device)
    model.load_state_dict(ckpt["model"])
    print(run_epoch(model, loader, device))

if __name__ == "__main__":
    main()
