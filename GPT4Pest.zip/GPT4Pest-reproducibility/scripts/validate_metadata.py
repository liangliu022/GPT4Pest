import argparse
import pandas as pd

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--images", required=True)
    p.add_argument("--descriptions")
    args = p.parse_args()
    df = pd.read_csv(args.images)
    required = ["image_id", "image_path", "label", "source_id", "is_augmented"]
    for col in required:
        if col not in df.columns:
            raise ValueError(f"Missing column: {col}")
    if df["image_id"].duplicated().any():
        raise ValueError("image_id values must be unique.")
    if df[["image_path", "label", "source_id"]].isna().any().any():
        raise ValueError("image_path, label, and source_id cannot be empty.")
    print("Image metadata OK")
    print("Files:", len(df))
    print("Classes:", df["label"].nunique())
    print("Original files:", (~df["is_augmented"].astype(str).str.lower().isin(["true","1","yes"])).sum())
    if args.descriptions:
        d = pd.read_csv(args.descriptions)
        if not {"image_id", "description"}.issubset(d.columns):
            raise ValueError("Descriptions CSV requires image_id and description.")
        if d["image_id"].duplicated().any():
            raise ValueError("Description image_id values must be unique.")
        print("Descriptions:", len(d))

if __name__ == "__main__":
    main()
