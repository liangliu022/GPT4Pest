import torch
from gpt4pest.losses import image_to_text_infonce

def test_infonce_finite():
    x = torch.nn.functional.normalize(torch.randn(4, 16), dim=-1)
    t = torch.nn.functional.normalize(torch.randn(4, 16), dim=-1)
    loss = image_to_text_infonce(x, t, 0.07)
    assert torch.isfinite(loss)
    assert loss.item() >= 0
